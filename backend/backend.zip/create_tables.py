# create_tables.py
import os
import sys

# Try to import your existing get_db_connection helper from application.py
try:
    # adjust the import path if your get_db_connection is in another module
    from application import get_db_connection
    def get_conn():
        return get_db_connection()
except Exception:
    # Fallback: build a pymysql connection using env vars
    import pymysql
    def get_conn():
        return pymysql.connect(
            host=os.getenv("DB_HOST"),
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASS"),
            database=os.getenv("DB_NAME"),
            cursorclass=pymysql.cursors.DictCursor,
            autocommit=True
        )

def create_tables():
    conn = get_conn()
    try:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS posts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title TEXT,
                blurb TEXT,
                writeup TEXT,
                media_type TEXT NOT NULL,
                media_href TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                is_visible TINYINT DEFAULT 1
            );
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS about (
                id INT AUTO_INCREMENT PRIMARY KEY,
                header TEXT,
                body TEXT,
                last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        """)
        # commit not required if autocommit True; safe to call anyway
        try:
            conn.commit()
        except Exception:
            pass
        print("Tables created or already exist.")
    except Exception as e:
        print("Error creating tables:", e)
        raise
    finally:
        try:
            cursor.close()
        except Exception:
            pass
        try:
            conn.close()
        except Exception:
            pass

if __name__ == "__main__":
    create_tables()
